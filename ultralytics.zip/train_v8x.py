from ultralytics import YOLO

# Load a model

model = YOLO('yolov8x.pt')  # load a pretrained model (recommended for training)


# Train the model
results = model.train(data='/root/autodl-tmp/datasets/cctsdb.yaml',  # 训练参数均可以重新设置
                        epochs=200, 
                        imgsz=640, 
                        workers=64, 
                        batch=2,
                        )