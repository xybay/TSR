from ultralytics import YOLO

# Load a model

model = YOLO('yolov8s-EMA.yaml')  # load a pretrained model (recommended for training)
model.load("yolov8s.pt")

# Train the model
results = model.train(data='/root/autodl-tmp/datasets/cctsdb.yaml',  # 训练参数均可以重新设置
                        epochs=200, 
                        imgsz=640, 
                        workers=64, 
                        batch=16,
                        )